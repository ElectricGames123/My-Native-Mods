#include "StoneBrick.h"

bool StoneBrick::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	int data = getData(pos);
	int x = pos.x, y = pos.y, z = pos.z;
	
	//block.mBlocks[98]->setSolid(false);
	
	//(esquerda, cima, direita, baixo)
	
	_setShapeAndTessellate(tessellator, Vec3(0, 0, 0), Vec3(1, 1, 1), block, pos, 0);
	
	if(data == 0){BlockGraphics::mBlocks[98]->setTextureItem("stonebrick");}
	if(data == 1){BlockGraphics::mBlocks[98]->setTextureItem("stonebrick_mossy");}
	if(data == 2){BlockGraphics::mBlocks[98]->setTextureItem("stonebrick_cracked");}
	if(data == 3){BlockGraphics::mBlocks[98]->setTextureItem("stonebrick_carved");}
	
	if(data == 0 || data == 1 || data == 2){
		_setShapeAndTessellate(tessellator, Vec3(0, 0, 0), Vec3(1, 1, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 1, 0), Vec3(0.937, 1.05, 0.437), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 1, 0.5), Vec3(0.436, 1.05, 0.936), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.5, 1, 0.5), Vec3(1, 1.05, 0.937), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.563, 0.063), Vec3(1.05, 1, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.063, 0.563), Vec3(1.05, 0.5, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.063, 0), Vec3(1.05, 0.5, 0.5), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.563, 0), Vec3(0, 1, 0.936), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.063, 0.5), Vec3(0, 0.5, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.063, 0), Vec3(0, 0.5, 0.437), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0.563, 1), Vec3(0.936, 1, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0.063, 1), Vec3(0.437, 0.5, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.5, 0.063, 1), Vec3(1, 0.5, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.063, 0.563, -0.05), Vec3(1, 1, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.563, 0.063, -0.05), Vec3(1, 0.5, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0.063, -0.05), Vec3(0.5, 0.5, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0.563), Vec3(0.936, 0, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0.063), Vec3(0.437, 0, 0.5), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.5, -0.05, 0.063), Vec3(1, 0, 0.5), block, pos, 0);
	}
	
	if(data == 3){
		_setShapeAndTessellate(tessellator, Vec3(0.8, 1, 0), Vec3(1, 1.05, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 1, 0), Vec3(0.2, 1.05, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.2, 1, 0.8), Vec3(0.8, 1.05, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.2, 1, 0), Vec3(0.8, 1.05, 0.2), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 1, 0.25), Vec3(0.4, 1.05, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.6, 1, 0.25), Vec3(0.75, 1.05, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 1, 0.6), Vec3(0.75, 1.05, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 1, 0.25), Vec3(0.75, 1.05, 0.4), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.2, 0.8), Vec3(1.05, 0.8, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.2, 0), Vec3(1.05, 0.8, 0.2), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.8, 0), Vec3(1.05, 1, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0, 0), Vec3(1.05, 0.2, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.4, 0.25), Vec3(1.05, 0.6, 0.4), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.25, 0.25), Vec3(1.05, 0.4, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.4, 0.6), Vec3(1.05, 0.6, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(1, 0.6, 0.25), Vec3(1.05, 0.75, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.8, 0, 1), Vec3(1, 1, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0, 1), Vec3(0.2, 1, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0.8, 1), Vec3(1, 1, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0, 1), Vec3(1, 0.2, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.6, 0.25, 1), Vec3(0.75, 0.75, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.6, 1), Vec3(0.75, 0.75, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.25, 1), Vec3(0.75, 0.4, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.25, 1), Vec3(0.4, 0.75, 1.05), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.2, 0.8), Vec3(0, 0.8, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.2, 0), Vec3(0, 0.8, 0.2), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.8, 0), Vec3(0, 1, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0, 0), Vec3(0, 0.2, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.4, 0.25), Vec3(0, 0.6, 0.4), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.25, 0.25), Vec3(0, 0.4, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.4, 0.6), Vec3(0, 0.6, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.6, 0.25), Vec3(0, 0.75, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.8, 0, -0.05), Vec3(1, 1, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0, -0.05), Vec3(0.2, 1, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0.8, -0.05), Vec3(1, 1, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, 0, -0.05), Vec3(1, 0.2, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.6, 0.25, -0.05), Vec3(0.75, 0.75, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.6, -0.05), Vec3(0.75, 0.75, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.25, -0.05), Vec3(0.75, 0.4, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, 0.25, -0.05), Vec3(0.4, 0.75, 0), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.8, -0.05, 0), Vec3(1, 0, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0), Vec3(0.2, 0, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.2, -0.05, 0.8), Vec3(0.8, 0, 1), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.2, -0.05, 0), Vec3(0.8, 0, 0.2), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, -0.05, 0.25), Vec3(0.4, 0, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.6, -0.05, 0.25), Vec3(0.75, 0, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, -0.05, 0.6), Vec3(0.75, 0, 0.75), block, pos, 0);
		_setShapeAndTessellate(tessellator, Vec3(0.25, -0.05, 0.25), Vec3(0.75, 0, 0.4), block, pos, 0);
	}
	
	return true;
}
