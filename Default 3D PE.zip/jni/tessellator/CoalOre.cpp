#include "CoalOre.h"

bool CoalOre::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	//block.mBlocks[17]->setSolid(false);
	BlockGraphics::mBlocks[16]->setTextureItem("coal_ore");
	
	_setShapeAndTessellate(tessellator, Vec3(0.00, 0.00, 0.00), Vec3(1.00, 1.00, 1.00), block, pos, 0);
	
	BlockGraphics::mBlocks[16]->setTextureItem("coal_block");
		
	//top
	_setShapeAndTessellate(tessellator, Vec3(0.250, 1.00, 0.125), Vec3(0.312, 1.02, 0.187), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, 1.00, 0.186), Vec3(0.562, 1.05, 0.250), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.750, 1.00, 0.125), Vec3(0.875, 1.03, 0.187), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.311, 1.00, 0.310), Vec3(0.439, 1.05, 0.374), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.186, 1.00, 0.373), Vec3(0.500, 1.05, 0.439), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.625, 1.00, 0.311), Vec3(0.750, 1.03, 0.438), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.063, 1.00, 0.500), Vec3(0.187, 1.03, 0.563), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.250, 1.00, 0.625), Vec3(0.312, 1.02, 0.687), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, 1.00, 0.500), Vec3(0.625, 1.02, 0.562), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, 1.00, 0.562), Vec3(0.687, 1.02, 0.625), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.188, 1.00, 0.811), Vec3(0.312, 1.05, 0.874), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.687, 1.00, 0.687), Vec3(0.812, 1.05, 0.750), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, 1.00, 0.750), Vec3(0.874, 1.05, 0.812), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.563, 1.00, 0.812), Vec3(0.687, 1.05, 0.874), block, pos, 0);
	
	//bottom
	_setShapeAndTessellate(tessellator, Vec3(0.250, -0.02, 0.125), Vec3(0.312, 0.00, 0.187), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, -0.05, 0.186), Vec3(0.562, 0.00, 0.250), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.750, -0.03, 0.125), Vec3(0.875, 0.00, 0.187), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.311, -0.05, 0.310), Vec3(0.439, 0.00, 0.374), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.186, -0.05, 0.373), Vec3(0.500, 0.00, 0.439), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.625, -0.03, 0.311), Vec3(0.750, 0.00, 0.438), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.063, -0.03, 0.500), Vec3(0.187, 0.00, 0.563), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.250, -0.02, 0.625), Vec3(0.312, 0.00, 0.687), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, -0.02, 0.500), Vec3(0.625, 0.00, 0.562), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, -0.02, 0.562), Vec3(0.687, 0.00, 0.625), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.188, -0.05, 0.811), Vec3(0.312, 0.00, 0.874), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.687, -0.05, 0.687), Vec3(0.812, 0.00, 0.750), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, -0.05, 0.750), Vec3(0.874, 0.00, 0.812), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.563, -0.05, 0.812), Vec3(0.687, 0.00, 0.874), block, pos, 0);
	
	//idk
	_setShapeAndTessellate(tessellator, Vec3(0.250, 0.814, 1.00), Vec3(0.312, 0.876, 1.02), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, 0.750, 1.00), Vec3(0.562, 0.814, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.750, 0.814, 1.00), Vec3(0.875, 0.876, 1.03), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.311, 0.626, 1.00), Vec3(0.439, 0.690, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.186, 0.564, 1.00), Vec3(0.500, 0.628, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.625, 0.564, 1.00), Vec3(0.750, 0.690, 1.03), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.063, 0.438, 1.00), Vec3(0.187, 0.502, 1.03), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.250, 0.314, 1.00), Vec3(0.312, 0.374, 1.02), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, 0.438, 1.00), Vec3(0.625, 0.502, 1.02), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.437, 0.376, 1.00), Vec3(0.687, 0.438, 1.02), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.188, 0.126, 1.00), Vec3(0.312, 0.188, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.687,  0.250, 1.00), Vec3(0.812, 0.312, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.500, 0.188, 1.00), Vec3(0.874, 0.250, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.563, 0.126, 1.00), Vec3(0.687, 0.188, 1.05), block, pos, 0);
	
	//idk
	_setShapeAndTessellate(tessellator, Vec3(0.689, 0.814, -0.02), Vec3(0.752, 0.876, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.439, 0.750, -0.05), Vec3(0.566, 0.814, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.126, 0.814, -0.03), Vec3(0.254, 0.876, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.564, 0.626, -0.05), Vec3(0.690, 0.690, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.501, 0.564, -0.05), Vec3(0.814, 0.628, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.251, 0.564, -0.03), Vec3(0.378, 0.690, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.813, 0.438, -0.03), Vec3(0.938, 0.502, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.689, 0.314, -0.02), Vec3(0.752, 0.374, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.365, 0.438, -0.02), Vec3(0.500, 0.502, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.313, 0.376, -0.02), Vec3(0.562, 0.438, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.689, 0.126, -0.05), Vec3(0.814, 0.188, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.189,  0.250, -0.05), Vec3(0.314, 0.312, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.126, 0.188, -0.05), Vec3(0.500, 0.250, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.313, 0.126, -0.05), Vec3(0.438, 0.188, 0.00), block, pos, 0);
	
	//idk
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.814, 0.690), Vec3(1.02, 0.876, 0.752), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.750, 0.440), Vec3(1.05, 0.814, 0.566), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.814, 0.128), Vec3(1.03, 0.876, 0.254), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.626, 0.566), Vec3(1.05, 0.690, 0.690), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.564, 0.502), Vec3(1.05, 0.628, 0.814), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.564, 0.252), Vec3(1.03, 0.690, 0.378), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.438, 0.814), Vec3(1.03, 0.502, 0.938), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.314, 0.690), Vec3(1.02, 0.374, 0.752), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.438, 0.376), Vec3(1.02, 0.502, 0.500), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.376, 0.314), Vec3(1.02, 0.438, 0.562), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.126, 0.690), Vec3(1.05, 0.188, 0.814), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00,  0.250, 0.190), Vec3(1.05, 0.312, 0.314), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.188, 0.128), Vec3(1.05, 0.250, 0.500), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.126, 0.314), Vec3(1.05, 0.188, 0.438), block, pos, 0);
	
	//idk
	_setShapeAndTessellate(tessellator, Vec3(-0.02, 0.814, 0.250), Vec3(0.00, 0.876, 0.312), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.750, 0.437), Vec3(0.00, 0.814, 0.562), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.03, 0.814, 0.750), Vec3(0.00, 0.876, 0.875), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.626, 0.311), Vec3(0.00, 0.690, 0.439), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.564, 0.186), Vec3(0.00, 0.628, 0.500), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.03, 0.564, 0.625), Vec3(0.00, 0.690, 0.750), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.03, 0.438, 0.063), Vec3(0.00, 0.502, 0.187), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.02, 0.314, 0.250), Vec3(0.00, 0.374, 0.312), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.02, 0.438, 0.500), Vec3(0.00, 0.502, 0.625), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.02, 0.376, 0.437), Vec3(0.00, 0.438, 0.687), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.126, 0.188), Vec3(0.00, 0.188, 0.312), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05,  0.250, 0.687), Vec3(0.00, 0.312, 0.812), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.188, 0.500), Vec3(0.00, 0.250, 0.874), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.126, 0.563), Vec3(0.00, 0.188, 0.687), block, pos, 0);
	
	//(esquerda, cima, direita, baixo)
	
	BlockGraphics::mBlocks[16]->setTextureItem("coal_ore");
	
	return true;
}

