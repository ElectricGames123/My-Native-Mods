#include "QuartzBlock.h"

bool QuartzBlock::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	//block.mBlocks[155]->setSolid(false);
	//(esquerda, cima, direita, baixo)
	
	_setShapeAndTessellate(tessellator, Vec3(0.00, 0.00, 0.00), Vec3(1.00, 1.00, 1.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.12, 1.00, 0.122), Vec3(0.25, 1.03, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.122, 1.00, 0.12), Vec3(0.878, 1.03, 0.25), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.75, 1.00, 0.122), Vec3(0.878, 1.03, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.122, 1.00, 0.75), Vec3(0.878, 1.03, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.3, 1.00, 0.3), Vec3(0.7, 1.06, 0.7), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.12, -0.03, 0.122), Vec3(0.25, 0.00, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.122, -0.03, 0.12), Vec3(0.878, 0.00, 0.25), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.75, -0.03, 0.122), Vec3(0.878, 0.00, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.122, -0.03, 0.75), Vec3(0.878, 0.00, 0.878), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.3, -0.06, 0.3), Vec3(0.7, 0.00, 0.7), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, -0.03, 0.94), Vec3(0.19, 1.03, 1.06), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.31, -0.03, 0.94), Vec3(0.44, 1.03, 1.06), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.56, -0.03, 0.94), Vec3(0.69, 1.03, 1.06), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.81, -0.03, 0.94), Vec3(0.94, 1.03, 1.06), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, -0.03, -0.06), Vec3(0.19, 1.03, 0.07), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.31, -0.03, -0.06), Vec3(0.44, 1.03, 0.07), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.56, -0.03, -0.06), Vec3(0.69, 1.03, 0.07), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.81, -0.03, -0.06), Vec3(0.94, 1.03, 0.07), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.94, -0.03, 0.06), Vec3(1.06, 1.03, 0.19), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.94, -0.03, 0.31), Vec3(1.06, 1.03, 0.44), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.94, -0.03, 0.56), Vec3(1.06, 1.03, 0.69), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.94, -0.03, 0.81), Vec3(1.06, 1.03, 0.94), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.06, -0.03, 0.06), Vec3(0.07, 1.03, 0.19), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.06, -0.03, 0.31), Vec3(0.07, 1.03, 0.44), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.06, -0.03, 0.56), Vec3(0.07, 1.03, 0.69), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.06, -0.03, 0.81), Vec3(0.07, 1.03, 0.94), block, pos, 0);
	
	return true;
}
