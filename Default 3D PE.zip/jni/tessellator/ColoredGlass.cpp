#include "ColoredGlass.h"

bool ColoredGlass::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	int data = getData(pos);
	int x = pos.x, y = pos.y, z = pos.z;
	
	//block.mBlocks[241]->setSolid(false);
	//BlockGraphics::mBlocks[241]->setTextureItem("idk");
	
	//(esquerda, cima, direita, baixo)
	
	_setShapeAndTessellate(tessellator, Vec3(0, 0, 0), Vec3(1, 1, 1), block, pos, 0);
	
	_setShapeAndTessellate(tessellator, Vec3(0.94, 1, 0), Vec3(1, 1.05, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0, 1, 0), Vec3(0.06, 1.05, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, 1, 0.94), Vec3(0.94, 1.05, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, 1, 0), Vec3(0.94, 1.05, 0.06), block, pos, 0);

	_setShapeAndTessellate(tessellator, Vec3(0.94, -0.05, 0), Vec3(1, 0, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0), Vec3(0.06, 0, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, -0.05, 0.94), Vec3(0.94, 0, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, -0.05, 0), Vec3(0.94, 0, 0.06), block, pos, 0);

	_setShapeAndTessellate(tessellator, Vec3(1, 0.94, 0.06), Vec3(1.05, 1, 0.94), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1, 0, 0.06), Vec3(1.05, 0.06, 0.94), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1, 0, 0.94), Vec3(1.05, 1, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1, 0, 0), Vec3(1.05, 1, 0.06), block, pos, 0);

	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.94, 0.06), Vec3(0, 1, 0.94), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0, 0.06), Vec3(0, 0.06, 0.94), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0, 0.94), Vec3(0, 1, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0, 0), Vec3(0, 1, 0.06), block, pos, 0);

	_setShapeAndTessellate(tessellator, Vec3(0.06, 0.92, 1), Vec3(0.94, 1, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, 0, 1), Vec3(0.94, 0.06, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.92, 0, 1), Vec3(1, 1, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0, 0, 1), Vec3(0.06, 1, 1.05), block, pos, 0);

	_setShapeAndTessellate(tessellator, Vec3(0.06, 0.92, -0.05), Vec3(0.94, 1, 0), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.06, 0, -0.05), Vec3(0.94, 0.06, 0), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.92, 0, -0.05), Vec3(1, 1, 0), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0, 0, -0.05), Vec3(0.06, 1, 0), block, pos, 0);
	
	return true;
}
