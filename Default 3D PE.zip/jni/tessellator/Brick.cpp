#include "Brick.h"

bool Brick::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	int data = getData(pos);
	int x = pos.x, y = pos.y, z = pos.z;
	
	//block.mBlocks[45]->setSolid(false);
	
	//(esquerda, cima, direita, baixo)
	
	_setShapeAndTessellate(tessellator, Vec3(0 , 0, 0), Vec3(1, 1, 1), block, pos, 0);

	 _setShapeAndTessellate(tessellator, Vec3(0, 1, 0), Vec3(0.2, 1.05, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 1, 0), Vec3(1, 1.05, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 1, 0.252), Vec3(0.438, 1.05, 0.438), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 1, 0), Vec3(0.7, 1.05, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 1, 0.252), Vec3(0.94, 1.05, 0.438), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 1, 0.5), Vec3(0.2, 1.05, 0.69), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 1, 0.5), Vec3(1, 1.05, 0.69), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 1, 0.75), Vec3(0.44, 1.05, 0.94), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 1, 0.75), Vec3(1, 1.05, 0.94), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 1, 0.5), Vec3(0.7, 1.05, 0.69), block, pos, 0);
	
	_setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0), Vec3(0.2, 0, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, -0.05, 0), Vec3(1, 0, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0.252), Vec3(0.438, 0, 0.438), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, -0.05, 0), Vec3(0.7, 0, 0.19), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, -0.05, 0.252), Vec3(0.94, 0, 0.438), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0.5), Vec3(0.2, 0, 0.69), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, -0.05, 0.5), Vec3(1, 0, 0.69), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, -0.05, 0.75), Vec3(0.44, 0, 0.94), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, -0.05, 0.75), Vec3(1, 0, 0.94), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, -0.05, 0.5), Vec3(0.7, 0, 0.69), block, pos, 0);
 
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.815, 0.815), Vec3(1.05, 1, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1, 0.815, 0.31), Vec3(1.05, 1, 0.75), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.563, 0.56), Vec3(1.05, 0.75, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.563, 0), Vec3(1.05, 0.75, 0.5), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.815, 0), Vec3(1.05, 1, 0.25), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.315, 0.81), Vec3(1.05, 0.5, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.315, 0), Vec3(1.05, 0.5, 0.25), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.065, 0.55), Vec3(1.05, 0.25, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.065, 0.065), Vec3(1.05, 0.25, 0.5), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(1, 0.315, 0.31), Vec3(1.05, 0.5, 0.75), block, pos, 0);
	
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.815, 0.815), Vec3(0, 1, 1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.815, 0.31), Vec3(0, 1, 0.75), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.563, 0.56), Vec3(0, 0.75, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.563, 0), Vec3(0, 0.75, 0.5), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.815, 0), Vec3(0, 1, 0.25), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.315, 0.81), Vec3(0, 0.5, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.315, 0), Vec3(0, 0.5, 0.25), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.065, 0.55), Vec3(0, 0.25, 1), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.065, 0.065), Vec3(0, 0.25, 0.5), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(-0.05, 0.315, 0.31), Vec3(0, 0.5, 0.75), block, pos, 0);
 
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.815, 1), Vec3(0.2, 1, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 0.815, 1), Vec3(0.7, 1, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 0.815, 1), Vec3(1, 1, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.563, 1), Vec3(0.44, 0.75, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 0.563, 1), Vec3(0.94, 0.75, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.315, 1), Vec3(0.2, 0.5, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 0.315, 1), Vec3(0.7, 0.5, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 0.315, 1), Vec3(1, 0.5, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.063, 1), Vec3(0.44, 0.25, 1.05), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 0.063, 1), Vec3(1, 0.25, 1.05), block, pos, 0);
	
	_setShapeAndTessellate(tessellator, Vec3(0, 0.815, -0.05), Vec3(0.2, 1, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 0.815, -0.05), Vec3(0.7, 1, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 0.815, -0.05), Vec3(1, 1, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.563, -0.05), Vec3(0.44, 0.75, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 0.563, -0.05), Vec3(0.94, 0.75, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.315, -0.05), Vec3(0.2, 0.5, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.25, 0.315, -0.05), Vec3(0.7, 0.5, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.75, 0.315, -0.05), Vec3(1, 0.5, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0, 0.063, -0.05), Vec3(0.44, 0.25, 0), block, pos, 0);
	 _setShapeAndTessellate(tessellator, Vec3(0.5, 0.063, -0.05), Vec3(1, 0.25, 0), block, pos, 0);

	return true;
}
