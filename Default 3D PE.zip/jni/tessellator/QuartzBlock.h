#pragma once

#include "mcpe/client/renderer/BlockTessellator.h"

class QuartzBlock : public BlockTessellator {
public:
	bool tessellate(BlockTessellator* bt, Tessellator&, Block const&, BlockPos const&, unsigned char, bool);
};

