#include "Log.h"

bool Log::tessellate(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	
	int data = getData(pos);
	int x = pos.x, y = pos.y, z = pos.z;
	
	//(esquerda, cima, direita, baixo)
	
	//block.mBlocks[17]->setSolid(false);
	
	if(data == 0){BlockGraphics::mBlocks[17]->setTextureItem("log_oak_top", "log_oak_top", "log_oak");}
	if(data == 1){BlockGraphics::mBlocks[17]->setTextureItem("log_spruce_top", "log_spruce_top", "log_spruce");}
	if(data == 2){BlockGraphics::mBlocks[17]->setTextureItem("log_birch_top", "log_birch_top", "log_birch");}
	if(data == 3){BlockGraphics::mBlocks[17]->setTextureItem("log_jungle_top", "log_jungle_top", "log_jungle");}
	
	_setShapeAndTessellate(tessellator, Vec3(0.00, 0.00, 0.00), Vec3(1.00, 1.00, 1.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.00, 0.00, 0.1), Vec3(1.05, 1.00, 0.9), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(1.05, 0.00, 0.2), Vec3(1.1, 1.00, 0.8), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.05, 0.00, 0.1), Vec3(0.00, 1.00, 0.9), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(-0.1, 0.00, 0.2), Vec3(-0.05, 1.00, 0.8), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.1, 0.00, 1.00), Vec3(0.9, 1.00, 1.05), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.2, 0.00, 1.05), Vec3(0.8, 1.00, 1.1), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.1, 0.00, -0.05), Vec3(0.9, 1.00, 0.00), block, pos, 0);
	_setShapeAndTessellate(tessellator, Vec3(0.2, 0.00, -0.1), Vec3(0.8, 1.00, -0.05), block, pos, 0);
	
	return true;
}
