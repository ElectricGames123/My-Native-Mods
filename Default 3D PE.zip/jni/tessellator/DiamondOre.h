#pragma once

#include "mcpe/client/renderer/BlockTessellator.h"

class DiamondOre : public BlockTessellator {
public:
	bool tessellate(BlockTessellator* bt, Tessellator&, const Block&, BlockPos const&, unsigned char, bool);
};

