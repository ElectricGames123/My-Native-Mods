#pragma once;

#include "mcpe/block/Block.h"
#include "mcpe/level/BlockSource.h"
#include "mcpe/block/BlockGraphics.h"
#include "mcpe/util/Vec3.h"

class Tessellator;
class BlockPos;

class BlockTessellator {
public:
	void _setShapeAndTessellate(Tessellator&, Vec3 const&, Vec3 const&, Block const&, BlockPos const&, int);
	bool tessellateInWorld(Tessellator&, Block const&, BlockPos const&, unsigned char, bool);
	int getData(BlockPos const&) const;
	BlockSource& getRegion() const;
};
