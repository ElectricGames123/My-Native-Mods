#pragma once

#include <string>

class ClientInstance;
class Player;

class MinecraftGame {
public:
	void onPlayerLoaded(ClientInstance&, Player&);
	void sendLocalMessage(std::string const&, std::string const&);
};
