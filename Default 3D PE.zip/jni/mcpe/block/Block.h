#pragma once

#include <string>

#define BLOCK_ID_SIZE 256

class Block {
public:
	static Block* mBlocks[BLOCK_ID_SIZE];
};
