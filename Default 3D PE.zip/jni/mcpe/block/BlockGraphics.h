#pragma once

#include <string>

#include "Block.h"

class BlockGraphics {
public:
	static BlockGraphics* mBlocks[BLOCK_ID_SIZE];
	
	void setTextureItem(const std::string&);
	void setTextureItem(const std::string&, const std::string&, const std::string&);
	void setTextureItem(const std::string&, const std::string&, const std::string&, const std::string&, const std::string&, const std::string&);
};