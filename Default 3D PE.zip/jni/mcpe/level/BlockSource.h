#pragma once 

class BlockPos;

class BlockSource {
public:
	int getData(BlockPos const&);
};
