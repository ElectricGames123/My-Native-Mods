#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdlib.h>
#include <substrate.h>

#include "mcpe/client/MinecraftGame.h"
#include "mcpe/client/renderer/BlockTessellator.h"

#include "tessellator/GoldOre.h"
#include "tessellator/IronOre.h"
#include "tessellator/CoalOre.h"
#include "tessellator/DiamondOre.h"
#include "tessellator/RedstoneOre.h"
#include "tessellator/QuartzBlock.h"
#include "tessellator/StoneBrick.h"
#include "tessellator/ColoredGlass.h"
#include "tessellator/Log.h"
#include "tessellator/Brick.h"

void (*_onPlayerLoaded)(MinecraftGame*, ClientInstance&, Player&);
void onPlayerLoaded(MinecraftGame* mc, ClientInstance& ci, Player& player){
	mc->sendLocalMessage("Default 3D§6 v0.1", "\n§3By Electric\n§ePlease leave the credits!\n§cYoutube.com/c/ElectricGames1\n§bTwitter: @ElectricG123");
}

bool (*_tessellateInWorld)(BlockTessellator*, Tessellator&, Block const&, BlockPos const&, unsigned char, bool);
bool tessellateInWorld(BlockTessellator* bt, Tessellator& tessellator, Block const& block, BlockPos const& pos, unsigned char c, bool b){
	if(&block == Block::mBlocks[14])
		return ((GoldOre*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[15])
		return ((IronOre*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[16])
		return ((CoalOre*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[17])
		return ((Log*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[45])
		return ((Brick*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[56])
		return ((DiamondOre*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[73] || &block == Block::mBlocks[74])
		return ((RedstoneOre*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[98])
		return ((StoneBrick*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[155] && bt->getRegion().getData(pos) == 2)
		return ((QuartzBlock*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	if(&block == Block::mBlocks[241])
		return ((ColoredGlass*) bt)->tessellate(bt, tessellator , block, pos, c, b);
	return _tessellateInWorld(bt, tessellator, block, pos, c, b);
}

#define hook(a, b, c) MSHookFunction((void*) &a, (void*) &b, (void**) &c);

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	
	hook(MinecraftGame::onPlayerLoaded, onPlayerLoaded, _onPlayerLoaded);
	hook(BlockTessellator::tessellateInWorld, tessellateInWorld, _tessellateInWorld);
	
	return JNI_VERSION_1_2;
}
